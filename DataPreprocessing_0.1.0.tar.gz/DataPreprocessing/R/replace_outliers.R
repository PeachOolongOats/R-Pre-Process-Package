#' Replace Outliers
#'
#' \code{replace_outliers} identifies and replaces outliers in a numeric vector of values using various methods.
#' Additionally, it provides an option to visualize the comparison between the original and modified data.
#'
#' @param data A data frame containing the dataset.
#' @param column The name of the column containing the numeric vector of values to be processed,
#' or the column index of the column.
#' @param method A character string specifying the method used to detect outliers.
#'   Choose from \code{"3sigma"} (default), \code{"IQR"}, or \code{"MAD"}.
#'   - For \code{"3sigma"}, outliers are identified based on three standard deviations from the mean.
#'   - For \code{"IQR"}, outliers are identified based on the interquartile range.
#'   - For \code{"MAD"}, outliers are identified based on the median absolute deviation.
#' @param replace_method A character string specifying the method used to replace outliers.
#'   Choose from \code{"mean"} (default), \code{"median"}, \code{"zero"}, or \code{"custom"}.
#'   - For \code{"mean"}, outliers are replaced with the mean of non-outlier values.
#'   - For \code{"median"}, outliers are replaced with the median of non-outlier values.
#'   - For \code{"zero"}, outliers are replaced with zero.
#'   - For \code{"custom"}, outliers are replaced with a user-defined value specified by \code{replace_value}.
#' @param new_column A logical parameter indicating whether the function should create a new column.
#'   If \code{TRUE} (default), a new column with the prefix "no_outlier_" will be created to store the new values.
#'   If \code{FALSE}, the original column will be replaced with the new values.
#' @param get_picture Logical indicating whether to generate a comparison plot of original and modified data. Default is \code{TRUE}.
#' @param replace_value If \code{replace_method} is \code{"custom"}, specify the value to replace outliers with.
#'
#' @return A data frame with outliers replaced according to the specified method.
#'
#' @examples
#' set.seed(123)
#' df <- data.frame(value = c(rnorm(100, mean = 10, sd = 2), 100))
#' # Replace outliers in column "value" using the default 3sigma method and visualize the comparison plot
#' replace_outliers(df, column = "value", new_column = TRUE)
#'
#' df <- data.frame(value = c(1, 2, 3, 4, 100, 6, 7, 8, 9, 10))
#' # Replace outliers in column "value" using the IQR method and replace them with the median
#' replace_outliers(df, column = "value", method = "IQR", replace_method = "median", new_column = FALSE)
#'
#' @import ggplot2
#'
#' @export


replace_outliers <- function(data, column, method = "3sigma", replace_method = "mean", new_column = TRUE, get_picture = TRUE, replace_value = NULL) {
  original_values <- data[[column]]
  values <- data[[column]]

  if (method == "3sigma") {
    # Calculate mean and standard deviation
    mean_val <- mean(values)
    sd_val <- sd(values)

    # Calculate threshold values for outliers
    Tmin <- mean_val - 3 * sd_val
    Tmax <- mean_val + 3 * sd_val

    # Find outliers
    outliers <- values < Tmin | values > Tmax
  }

  if (method == "IQR") {
    # Calculate quartiles
    Q1 <- quantile(values, 0.25)
    Q3 <- quantile(values, 0.75)

    # Calculate IQR
    IQR <- Q3 - Q1

    # Calculate threshold values for outliers
    Tmin <- Q1 - 1.5 * IQR
    Tmax <- Q3 + 1.5 * IQR

    # Find outliers
    outliers <- values < Tmin | values > Tmax
  }

  if (method == "MAD") {
    # Calculate median
    med <- median(values)
    # Subtract median from each value of x and get absolute deviation
    abs_dev <- abs(values - med)
    # Calculate MAD
    mad <- 1.4826 * median(abs_dev)

    # Get threshold values for outliers
    Tmin <- med - (3 * mad)
    Tmax <- med + (3 * mad)

    # Find outliers
    outliers <- values < Tmin | values > Tmax
  }

  # Replace outliers
  if (replace_method == "median") {
    values[outliers] <- median(values[!outliers])
  } else if (replace_method == "mean") {
    values[outliers] <- mean(values[!outliers])
  } else if (replace_method == "zero") {
    values[outliers] <- 0
  } else if (replace_method == "custom") {
    if (is.null(replace_value)) {
      stop("You must specify a value for replace_value when replace_method is 'custom'.")
    }
    values[outliers] <- replace_value
  }

  # Create new column or replace existing column
  if (new_column) {
    new_outlier_column <- paste("no_outlier_", column, sep = "")
    data[[new_outlier_column]] <- values
  } else {
    data[[column]] <- values
  }

  if (get_picture) {
    data_to_plot <- data.frame(
      Value = c(original_values, values),
      Type = rep(c("Original", "Modified"), each = length(original_values))
    )

    p <- ggplot(data_to_plot, aes(x = Type, y = Value, fill = Type)) +
      geom_violin(trim = FALSE) +
      geom_jitter(width = 0.2, color = "black", size = 0.5, alpha = 0.5) +
      labs(title = "Comparison of data before and after handling outliers", x = "", y = "Value") +
      theme_minimal()
    print(p)
  }

  return(data)
}
