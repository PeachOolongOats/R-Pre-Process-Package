#' Encode Quantitative Variables
#'
#' \code{encode_quantitative} is used to encode quantitative variables based on specified methods,
#' including using mean or quantiles.
#'
#' @param data A data frame containing the quantitative variable to be encoded.
#' @param column A character string specifying the name of the column to be encoded,
#' or the column index of the column.
#' @param method A character string specifying the encoding method.
#'   Choose from \code{"mean"} or \code{"quantile"}.
#'
#'   - For \code{"mean"}, values greater than or equal to the mean will be encoded as 1, and others as 0.
#'
#'   - For \code{"quantile"}, values will be encoded based on quantiles.
#' @param q An integer specifying the number of quantiles for the "quantile" method. Default is 2.
#' @param new_column A logical parameter indicating whether the function should create a new column
#'   If \code{TRUE} (default), a new column with the prefix "encoded_" will be created to store the encoded values.
#'   If \code{FALSE}, the original column will be replaced with the encoded values.
#'
#' @return The data frame after encoding.
#'
#' @examples
#' df <- data.frame(category = c("A", "B", "C", "A", "B", "C", "A", "B", "C", "A", "B", "C"),
#'                  value = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12))
#' encode_quantitative(df, column = "value", method = "mean")
#' encode_quantitative(df, column = "value", method = "quantile", q = 3)
#'
#' @export

encode_quantitative <- function(data, column, method, q = 2, new_column = TRUE) {
  # Check if the column contains numeric data
  if (!is.numeric(data[[column]])) {
    stop("Column '", column, "' is not numeric.")
  }

  # Check the method parameter
  if (!(method %in% c("mean", "quantile"))) {
    stop("Invalid method parameter. Choose from 'mean' or 'quantile'.")
  }

  # Encode based on different methods
  if (method == "mean") {
    encoded <- ifelse(data[[column]] >= mean(data[[column]]), 1, 0)
  } else if (method == "quantile") {
    if (q < 2 | q%%1 != 0) {
      stop("Invalid q parameter. q must be an integer and at least 2.")
    }
    quantiles <- quantile(data[[column]], probs = seq(0, 1, by = 1/q))
    encoded <- cut(data[[column]], breaks = quantiles, labels = FALSE, include.lowest = TRUE)
  }

  # Create a new column or overwrite the original column
  if (new_column) {
    new_column <- paste("encoded_", column, sep = "")
    data[[new_column]] <- encoded
  } else {
    data[[column]] <- encoded
  }

  return(data)
}


