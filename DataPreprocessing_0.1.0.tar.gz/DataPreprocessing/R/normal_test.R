#' Normality Test
#'
#' \code{normal_test} function performs the Shapiro-Wilk normality test on each column of the given dataframe.
#' This test assesses whether the data in each column follows a normal distribution.
#'
#' @param data A dataframe containing the data to be tested for normality.
#' @param significance_level The significance level for the Shapiro-Wilk test. Defaults to \code{0.05}.
#' @param verbose A logical value indicating whether to print the p-values of the Shapiro-Wilk test for each column. Defaults to \code{TRUE}.
#'
#'
#' @return A vector containing the names of columns for which the p-value of the Shapiro-Wilk test
#' is greater than 0.05, indicating that the data in those columns approximately follows a normal distribution.
#'
#' @examples
#' df <- data.frame(
#'   Feature1 = c(1.1, 1.4, 1.9, 2.5),
#'   Feature2 = c(0.1, 0.24, 0.6, 0.7),
#'   Feature3 = c(0.6, 0.4, 0.8, 0.2)
#' )
#' normal_test(df, significance_level = 0.05, verbose = TRUE)
#'
#'
#' @export

normal_test <- function(data, significance_level = 0.05, verbose = TRUE) {

  # Check if it is dataframe
  if (!is.data.frame(data)) {
    stop("Error: Input data must be a data frame.")
  }

  # Check if it is numeric
  if (!all(sapply(data, is.numeric))) {
    stop("Error: The test can only test numeric variables.")
  }

  normality_test_results <- sapply(data, function(column) {
    shapiro.test(column)$p.value
  })

  if (verbose) {
    print(normality_test_results)
  }

  normal_params <- names(normality_test_results)[normality_test_results > significance_level]

  return(normal_params)

}
