#' DataPreprocessing: A package for data preprocessing
#'
#' Introduction: The DataPreprocessing package provides the following features:
#' \enumerate{
#'     \item Data Encoding
#'     \item Data Standardization
#'     \item Abnormal Data Handling
#'     \item Feature Engineering & Dimensionality Reduction
#'     \item Normality Testing
#' }
#'
#' @section Data Encoding functions:
#' \itemize{
#'  \item The \code{encode_categorical} function encodes categorical variables as numerical representations 
#'  and can visualize their distribution using a Nightingale Rose Chart, an advanced version of a pie chart.
#'  \item The \code{encode_categorical} function encodes quantitative variables using specified methods.
#' }
#' 
#' @section Data Standardization function:
#' \itemize{
#'  \item The \code{standardize} function standardizes data using specified methods 
#'  and can generate a boxplot for comparison.
#' }
#'
#' @section Abnormal Data Handling functions:
#' \itemize{
#'  \item The \code{missing_values} function handles missing values in a dataframe column using specified methods. 
#'  \item The \code{replace_outliers} function detects and replaces outliers using specified methods,
#'  and can generate a comparison plot.
#'  \item The \code{balance_sample} function balances the class distribution in a dataset by oversampling the minority class,
#'  and can generate a treemap visualization of class distribution before and after balancing
#' }
#'
#' @section Feature Engineering & Dimensionality Reduction functions:
#' \itemize{
#'  \item The \code{featureSelectionPearson} function identifies and selects relevant features based on Pearson correlation coefficients,
#'  and can generate a heatmap of the correlation matrix.
#'  \item The \code{pca} function performs Principal Component Analysis (PCA) for dimensionality reduction.
#' }
#'  
#' @section Normality Testing function:
#'  \itemize{
#'   \item The \code{pca} function performs the Shapiro-Wilk normality test to assess the normality of data.
#'  }
#'   
#' @name DataPreprocessing
NULL