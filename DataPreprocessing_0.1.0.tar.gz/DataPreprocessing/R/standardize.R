#' Standardize Data
#'
#' \code{standardize} is a function used to standardize a numeric column in a dataframe.
#' Standardization (also known as normalization) rescales the values of a numeric column to a common scale,
#' which is often useful for machine learning algorithms and statistical analyses.
#'
#' @param data A data frame containing the dataset.
#' @param column The name of the column containing the numeric vector of values to be standardized.
#' @param method A character string specifying the method used for standardization.
#'   Choose from \code{"min-max"} (default), \code{"z-score"}, or \code{"decimal"}.
#'   - For \code{"min-max"} scaling, the values are scaled to a range between 0 and 1.
#'   - For \code{"z-score"} scaling, the values are scaled to have a mean of 0 and a standard deviation of 1.
#'   - For \code{"decimal"} scaling, the values are scaled by shifting the decimal point.
#' @param new_column Logical indicating whether to create a new column for the standardized data.
#'   If \code{TRUE} (default), a new column with the prefix "standardized_" will be created to store the standardized values.
#'   If \code{FALSE}, the original column will be replaced with the standardized values.
#' @param get_picture Logical indicating whether to generate a boxplot comparison of original and standardized data.
#'   Default is \code{TRUE}.
#'
#' @return A data frame with the specified numeric column standardized.
#'
#' @examples
#' df <- data.frame(
#'   A = c(10, 20, 30, 40),
#'   B = c(-0.1, 0.5, 0.9, 1.8),
#'   C = c(100, 200, 300, 400)
#' )
#' # Standardize column "A" using the default min-max scaling method
#' standardize(df, column = "A")
#'
#' # Standardize column "B" using z-score scaling and visualize the boxplot comparison
#' standardize(df, method = "z-score", column = "B")
#'
#' @importFrom ggplot2 geom_boxplot labs theme_minimal
#' @importFrom reshape2 melt
#'
#' @export

standardize <- function(data, column, method = "min-max", new_column = TRUE, get_picture = TRUE) {
  original_values <- data[[column]]
  values <- data[[column]]

  if (method == "min-max") {
    # Min-max scaling
    scaled_column <- (values - min(values)) / (max(values) - min(values))
  } else if (method == "z-score") {
    # Z-score scaling
    scaled_column <- scale(values)
  } else if (method == "decimal") {
    # Decimal scaling
    max_abs <- max(abs(values))
    j <- floor(log10(max_abs))
    scaled_column <- values / 10^(j+1)
  } else {
    stop("Invalid method specified. Please choose 'min-max', 'z-score', or 'decimal'.")
  }

  # Generate new column name
  if (new_column) {
    new_name <- paste0("standardized_", column)
  } else {
    new_name <- column
  }

  if (new_column) {
    # Add the standardized data as a new column to the dataframe
    data[[new_name]] <- scaled_column
  } else {
    # Replace the original column with the standardized data
    data[[column]] <- scaled_column
  }

  if (get_picture) {
    # Create a long format dataframe for plotting
    plot_data <- data.frame(
      Original = original_values,
      Standardized = scaled_column
    )

    # Melt the data for ggplot2, specifying variable names explicitly
    plot_data_long <- melt(plot_data, measure.vars = c("Original", "Standardized"))

    # Generate boxplot
    p <- ggplot(plot_data_long, aes(x = variable, y = value, fill = variable)) +
      geom_boxplot() +
      labs(title = paste("Boxplot Comparison for", column, "before and after standardization"),
           x = "Condition",
           y = "Values") +
      theme_minimal()

    print(p)
  }

  return(data)
}





