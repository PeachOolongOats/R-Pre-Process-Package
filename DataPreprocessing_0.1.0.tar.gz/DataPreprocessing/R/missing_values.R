#' Handle Missing Values
#'
#' \code{missing_values} function provides functionality to handle missing values in a dataframe column using various methods.
#'
#' @param data A dataframe containing the dataset.
#' @param column The name of the column containing the data with missing values,
#' or the column index of the column.
#' @param fill_method The method to use for filling missing values.
#' Options include \code{"mode"} (replace with mode, the default), \code{"mean"} (replace with mean), \code{"median"} (replace with median), \code{"previous"} (replace with previous value),
#' \code{"next"} (replace with next value), or \code{"fixed"} (replace with a fixed value specified in \code{fill_value}).
#' @param fill_value The value to use for filling missing values when \code{fill_method} is set to \code{"fixed"}.
#' Ignored for other fill methods.
#'
#' @return The dataframe with missing values replaced according to the specified method.
#'
#' @examples
#' # Example usage:
#' df <- data.frame(
#'   A = c(1, 2, NA, 4, 5),
#'   B = c("a", NA, "c", NA, "e")
#' )
#'
#' # Replace missing values with mode for numeric column A and with previous value for non-numeric column B
#' df_filled <- missing_values(df, "A", fill_method = "mode")
#' df_filled
#' df_filled <- missing_values(df_filled, 2, fill_method = "previous")
#' df_filled
#'
#' @importFrom zoo na.locf
#'
#' @export

missing_values <- function(data, column, fill_method = "mode", fill_value = "mode") {
  # Get the column of interest
  values <- data[[column]]

  Mode <- function(x, na.rm = FALSE) {
    if (na.rm) {
      x <- x[!is.na(x)]
    }
    ux <- unique(x)
    ux[which.max(tabulate(match(x, ux)))]
  }

  # Check if the column is numeric
  if (is.numeric(values)) {
    # For numeric variables, handle missing values based on selected method
    if (fill_method == "mode") {
      # Replace missing values with mode
      values[is.na(values)] <- Mode(values, na.rm = TRUE)
    } else if (fill_method == "mean") {
      # Replace missing values with mean
      values[is.na(values)] <- mean(values, na.rm = TRUE)
    } else if (fill_method == "median") {
      # Replace missing values with median
      values[is.na(values)] <- median(values, na.rm = TRUE)
    } else if (fill_method == "previous") {
      # Check if the first value is NA
      if (is.na(values[1])) {
        stop("The first value is NA. Cannot use 'previous' method.")
      }
      # Replace missing values with previous value
      values <- zoo::na.locf(values)
    } else if (fill_method == "next") {
      # Check if the last value is NA
      if (is.na(values[length(values)])) {
        stop("The last value is NA. Cannot use 'next' method.")
      }
      # Replace missing values with next value
      values <- zoo::na.locf(values, fromLast = TRUE)
    } else if (fill_method == "fixed") {
      # Replace missing values with fixed value
      values[is.na(values)] <- fill_value
    }
  } else {
    # For non-numeric variables, handle missing values differently
    if (!is.numeric(fill_value)) {
      if (fill_method %in% c("mean", "median")) {
        stop("For non-numeric variables, fill_method must be 'mode', 'previous', 'next', or 'fixed'.")
      }
    }
    if (fill_method == "mode") {
      # Replace missing values with mode
      mode_val <- Mode(values, na.rm = TRUE)
      values[is.na(values)] <- mode_val
    } else if (fill_method == "previous") {
      # Replace missing values with previous value
      values <- zoo::na.locf(values)
    } else if (fill_method == "next") {
      # Replace missing values with next value
      values <- zoo::na.locf(values, fromLast = TRUE)
    } else if (fill_method == "fixed") {
      # Replace missing values with fixed value
      values[is.na(values)] <- fill_value
    }
  }

  # Replace the column in the dataframe with the updated values
  data[[column]] <- values

  return(data)
}

