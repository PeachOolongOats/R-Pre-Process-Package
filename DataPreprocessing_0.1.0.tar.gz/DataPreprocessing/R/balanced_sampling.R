#' Balanced Sampling
#'
#' \code{balanced_sampling} is a function used to balance the class distribution in a dataset by oversampling the minority class.
#' This is particularly useful for imbalanced classification problems #' where one class is significantly underrepresented compared to others.
#'
#' @param data A data frame containing the dataset.
#' @param class The name of the column representing the target class for balancing.
#' @param print_result Logical indicating whether to print the original and balanced class distributions.
#' Default is \code{TRUE}.
#' @param get_picture Logical indicating whether to generate a treemap visualization of class distribution before and after balancing.
#' Default is \code{TRUE}.
#'
#' @return A new data frame with balanced class distribution.
#'
#' @examples
#' data <- data.frame(
#' feature1 = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
#' feature2 = c(0, 1, 0, 1, 0, 1, 0, 1, 0, 1),
#' class = c("A", "A", "A", "A", "B", "B", "B", "B", "C", "C")
#' )
#'
#' # Original class distribution
#' table(data$class)
#' # Using the balanced_sampling function
#' balanced_data <- balanced_sampling(data, class = "class")
#' # Balanced class distribution
#' table(balanced_data$class)
#'
#' @importFrom treemap treemap
#' @importFrom ROSE ROSE
#'
#' @export

balanced_sampling <- function(data, class, get_picture = TRUE, print_result = TRUE) {
  if(!class %in% names(data)) {
    stop("The class column does not exist in the dataframe.")
  }

  original_distribution <- table(data[[class]])

  min_class <- names(which.min(original_distribution))
  max_class <- names(which.max(original_distribution))

  sub_data <- data[data[[class]] %in% c(min_class, max_class), ]
  other_classes_data <- data[!data[[class]] %in% c(min_class, max_class), ]

  formula <- as.formula(paste(class, "~ ."))
  balanced_sub_data <- ROSE(formula, sub_data, seed = 1)$data

  new_data <- rbind(balanced_sub_data, other_classes_data)

  if (print_result == TRUE) {
    new_distribution <- table(new_data[[class]])
    cat("Original Class Distribution:\n")
    print(original_distribution)
    cat("\nBalanced Class Distribution:\n")
    print(new_distribution)
  }

  if (get_picture == TRUE) {
    combined_distribution <- rbind(data.frame(Class = names(original_distribution),
                                              Count = as.numeric(original_distribution), Type = 'Original'),
                                   data.frame(Class = names(new_distribution),
                                              Count = as.numeric(new_distribution), Type = 'Balanced'))
    treemap(combined_distribution,
            index = c("Type", "Class"),
            vSize = "Count",
            vColor = "Type",
            palette = c("#6a4c93", "#f4a688"),
            title = "Class Distribution Before and After Balancing",
            fontsize.labels = c(12, 10))
  }

  return(new_data)
}
