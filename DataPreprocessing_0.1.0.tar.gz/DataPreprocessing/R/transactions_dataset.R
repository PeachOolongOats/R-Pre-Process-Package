#' Investments Dataset Overview
#'
#' This dataset comprises details on 400,000 investment transactions across 27 major companies
#' distributed in 5 key sectors. The investment horizons range from 1 to 2 years, reflecting
#' short to medium-term financial commitments. It was created to facilitate the analysis of sector-specific trends in investment,
#' profitability, and financial health indicators across various major players in the global market.
#'
#' @format A data frame with 405258 rows and 24 variables:
#' \describe{
#'   \item{company}{\code{factor} with names of the companies including AAPL, AMZN, AXP, and others.}
#'   \item{sector}{\code{factor} Sectors to which the companies belong: AUTO, BANK, FMCG, RETAIL, TECH.}
#'   \item{horizon}{\code{integer} Investment horizon in days.}
#'   \item{amount}{\code{numeric} Amount of investment in USD.}
#'   \item{date_BUY_fix}{\code{Date} Purchase date of the investment, ranging from 2013/10/10 to 2018/10/9.}
#'   \item{date_SELL_fix}{\code{Date} Sale date of the investment, ranging from 2013/10/11 to 2020/9/18.}
#'   \item{price_BUY}{\code{numeric} Buying price per unit, ranging from 7.14 to 2013.00 USD.}
#'   \item{price_SELL}{\code{numeric} Selling price per unit, ranging from 4.23 to 2999.90 USD.}
#'   \item{Volatility_Buy}{\code{numeric} Volatility at the time of buying, ranging from 0.09 to 0.70.}
#'   \item{Volatility_sell}{\code{numeric} Volatility at the time of selling, ranging from 0.09 to 0.91.}
#'   \item{Sharpe_Ratio}{\code{numeric} Sharpe Ratio of the investment, ranging from 0.09 to 0.70.}
#'   \item{expected_return}{\code{numeric} Expected return on the investment, ranging from -0.28 to 1.02.}
#'   \item{inflation}{\code{numeric} Inflation rate during the investment period, includes values like 1.41, -0.15, etc.}
#'   \item{nominal_return}{\code{numeric} Nominal return on the investment calculated as (price_SELL - price_BUY) / price_BUY, ranging from -0.62 to 6.09.}
#'   \item{investment}{\code{character} Investment quality, categorized as GOOD or BAD. Approximately 34.7\% are GOOD and 62.2\% are BAD.}
#'   \item{ESG_ranking}{\code{numeric} Environmental, Social, and Governance ranking, ranging from 12 to 31.6.}
#'   \item{PE_ratio}{\code{numeric} Price to Earnings ratio of the investment, ranging from 0 to 1116.57.}
#'   \item{EPS_ratio}{\code{numeric} Earnings Per Share ratio, ranging from -6.56 to 29.87.}
#'   \item{PS_ratio}{\code{numeric} Price to Sales ratio, ranging from 0.16 to 24.49.}
#'   \item{PB_ratio}{\code{numeric} Price to Book ratio, ranging from 0 to 47.62.}
#'   \item{NetProfitMargin_ratio}{\code{numeric} Net Profit Margin ratio, ranging from -24.63 to 62.}
#'   \item{current_ratio}{\code{numeric} Liquidity ratio measuring a company's ability to pay short-term obligations, ranging from 0.61 to 13.56.}
#'   \item{roa_ratio}{\code{numeric} Return on Assets ratio, ranging from -12.99 to 38.13.}
#'   \item{roe_ratio}{\code{numeric} Return on Equity ratio, ranging from -99.49 to 47.25.}
#' }
#'
"transactions_dataset"
