#' Feature Selection using Pearson Correlation
#'
#' \code{featureSelectionPearson} is a function used to select features based on Pearson correlation coefficients
#' between each feature and a target variable. It calculates the Pearson correlation coefficient matrix for the
#' specified features and the target variable, then selects features with absolute correlation coefficients greater
#' than a specified threshold.
#'
#' @param data A data frame containing the dataset.
#' @param features A character vector specifying the names of the features to be considered for selection.
#' @param target A character string specifying the name of the target variable.
#' @param threshold A numeric value specifying the threshold for selecting features based on correlation coefficients.
#' Default is \code{0.5}.
#' @param get_picture Logical indicating whether to generate a heatmap of the correlation matrix.
#' Default is \code{TRUE}.
#' @param print_result Logical indicating whether to print the selected features
#' and their Pearson correlation coefficients with the target variable. Default is \code{TRUE}.
#'
#' @return A character vector containing the names of the selected features.
#'
#' @examples
#' df <- data.frame(
#'   Feature1 = c(1.1, 1.4, 1.9, 2.5),
#'   Feature2 = c(0.1, 0.24, 0.6, 0.7),
#'   Feature3 = c(0.6, 0.4, 0.8, 0.2),
#'   Target = c(10, 15, 20, 25)
#' )
#'
#' features <- c("Feature1", "Feature2", "Feature3")
#' selected_features <- featureSelectionPearson(df, features, 'Target', threshold = 0.6, get_picture = TRUE, print_result = TRUE)
#'
#' @importFrom corrplot corrplot.mixed
#'
#' @export


featureSelectionPearson <- function(data, features, target, threshold = 0.5, get_picture = TRUE, print_result = TRUE) {
  if (!target %in% names(data)) {stop("Target variable not found in the dataset.")}
  if (!all(features %in% names(data))) {stop("One or more features not found in the dataset.")}

  # Calculate the Pearson correlation coefficient matrix for the specified features and the target
  correlations <- cor(data[, c(features, target)], use = "complete.obs", method = "pearson")
  target_correlations <- correlations[target, features]

  # Optionally create the heatmap if get_picture is TRUE
  if (get_picture) {
    corrplot.mixed(correlations, tl.pos = "lt", tl.cex = 0.5, tl.col = "black", diag = 'l')
  }

  # Select features with absolute correlation greater than the threshold with the target
  selected_features <- names(which(abs(target_correlations) > threshold))

  # If no features meet the threshold, provide a message and return NULL
  if (length(selected_features) == 0) {
    cat("No features exceed the correlation threshold.\n")
    return(NULL)
  }

  # Print the selected feature names and their correlations
  if (print_result == TRUE) {
    cat("Selected features and their Pearson correlation coefficients with the target:\n")
    print(correlations[selected_features, target])
  }


  # Return the names of the selected features
  return(selected_features)
}
