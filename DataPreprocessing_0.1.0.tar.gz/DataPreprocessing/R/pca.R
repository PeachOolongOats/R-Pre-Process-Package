#' Principal Component Analysis (PCA)
#'
#' \code{pca} function conducts Principal Component Analysis (PCA) on a given dataframe to reduce its dimensionality
#' while retaining as much variance as possible. PCA is useful for simplifying high-dimensional datasets
#' and identifying patterns or trends within the data.
#'
#' This function calculates the cumulative proportion of variance explained and selects the number of principal components required to
#' achieve a cumulative proportion greater than the specified 95\% threshold.
#' The data is then projected onto the selected number of principal components to form a new dataset.
#'
#' @param data A dataframe containing the data for PCA.
#' @param scale_data Logical indicating whether to scale the data before performing PCA. Defaults to \code{TRUE}.
#' @param threshold The cumulative proportion threshold for selecting the number of principal components.
#' PCA will select the number of components required to achieve a cumulative proportion of variance explained greater than this threshold. Defaults to \code{0.95}.
#' @param verbose Logical indicating whether to print the summary of PCA results. Defaults to \code{TRUE}.
#'
#' @return A dataframe containing the reduced data after PCA,
#' where the original features have been transformed into a new set of uncorrelated variables (principal components).
#'
#' @examples
#' df <- data.frame(
#'   Feature1 = c(1.1, 1.4, 1.9, 2.5),
#'   Feature2 = c(0.1, 0.24, 0.6, 0.7),
#'   Feature3 = c(0.6, 0.4, 0.8, 0.2)
#' )
#' pca(df, scale_data = TRUE, threshold = 0.99, verbose = TRUE)
#'
#' @import magrittr
#'
#' @export

pca <- function(data, scale_data = TRUE, threshold = 0.95, verbose = TRUE) {
  if (!is.data.frame(data)) {
    stop("Error: Input data must be a data frame.")
  }

  if (!all(apply(data, 2, is.numeric))) {
    stop("Error: Not all columns are numeric.")
  }

  if (ncol(data) < 2) {
    stop("Error: Input data must contain at least two columns.")
  }

  if (anyNA(data)) {
    stop("Error: You need to deal with NA first.")
  }

  if (scale_data) {
    data<- scale(data)
  }

  pca_result <- prcomp(data, scale. = TRUE)

  # Cumulative Proportion > 95%
  cumulative_proportion <- pca_result$sdev^2 %>%
    cumsum() %>%
    `/`(sum(pca_result$sdev^2))
  num_components <- which.max(cumulative_proportion > threshold)

  # hold num_components PCA
  pca_result_selected <- prcomp(data[, -ncol(data)], scale. = TRUE, retx=TRUE, rank. = num_components)

  if (verbose) {
    print(summary(pca_result_selected))
  }

  # project the data on n PCA
  reduced_data <- as.data.frame(predict(pca_result_selected))

  return(reduced_data)

}
