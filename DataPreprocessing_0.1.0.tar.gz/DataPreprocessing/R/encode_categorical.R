#' Encode Categorical Variables and Visualize Distribution
#'
#' The \code{encode_categorical} function assigns numerical encodings to a categorical variable and optionally
#' visualizes the distribution using a Nightingale Rose Chart. This chart, an advanced version of a pie chart,
#' displays data in a circular format where each "slice" or "petal" represents a category. The area or size of
#' each slice is proportional to the frequency of the category it represents, providing a visual comparison
#' across categories.
#'
#' @param data The data frame containing the categorical variable to be encoded.
#' @param column A character string or the index of the column to be encoded.
#' @param encoding_map An optional list mapping categories to specific numerical encodings.
#' If NULL (default), the function uses sequential encoding based on the order of factor levels.
#' @param new_column Logical; if TRUE (default), a new column prefixed with "encoded_" is created
#' to store the numerical encodings. If FALSE, the original column is overwritten with the encoded values.
#' @param get_picture Logical; if TRUE (default), generates a Nightingale Rose Chart to illustrate
#' the distribution of the categories after encoding. If FALSE, no chart is generated.
#'
#' @details
#' In the chart:
#' - Each slice's radial length represents the category's frequency, making it easy to compare proportions.
#' - The central angle of each slice is constant, emphasizing differences in radius (and thus area),
#' rather than angles as in traditional pie charts.
#'
#' @examples
#' df <- data.frame(category = c("A", "B", "C", "A", "B", "C", "A", "B", "C", "A", "B", "C"),
#'                  value = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12))
#' encode_categorical(df, column = "category")
#' encode_categorical(df, column = 1, encoding_map = c("A" = 1, "B" = 2, "C" = 3), get_picture = TRUE)
#'
#' @importFrom ggplot2 aes coord_polar geom_bar geom_text labs theme_void position_stack
#'
#' @export

encode_categorical <- function(data, column, encoding_map = NULL, new_column = TRUE, get_picture = TRUE) {
  # If encoding_map is NULL, the original sequential encoding is used by default
  if (is.null(encoding_map)) {
    # Using factor encoding
    encoded <- as.integer(factor(data[[column]], levels = unique(data[[column]])))
    # Update encoding_map to match encodings to categories
    encoding_map <- setNames(unique(encoded), levels(factor(data[[column]])))
  } else {
    # If encoding_map is not empty, the given encoding is used
    encoded <- sapply(data[[column]], function(x) {
      if (x %in% names(encoding_map)) {
        encoding_map[[x]]
      } else {
        warning(paste("Category", x, "not found in encoding map. Encoding as NA."))
        NA
      }
    })
  }

  # If new_column is TRUE, the new column is created
  if (new_column) {
    new_column <- paste("encoded_", column, sep = "")
    data[[new_column]] <- encoded
  } else {
    # Otherwise, the original column is simply overwritten
    data[[column]] <- encoded
  }

  if (get_picture) {
    data_to_plot <- as.data.frame(table(data[[column]]))
    names(data_to_plot) <- c("Category", "Frequency")

    p <- ggplot(data_to_plot, aes(x = Category, y = Frequency, fill = Category)) +
      geom_bar(stat = "identity", width = 0.8) +
      coord_polar(theta = "x",start=0) +
      geom_text(aes(label = paste(Category, Frequency, sep = ": "), y = Frequency / 2), color = "black", size = 3, position = position_stack(vjust = 0.5)) +
      labs(title = paste("Nightingale Rose Chart of", column),
           x = NULL,
           y = "Frequency") +
      theme_void() +
      theme(legend.position = "none")

    print(p)  # Ensure the plot is displayed in non-interactive settings

  }
  return(data)
}
