test_that("standardize standardizes data correctly", {
  # Test case 1: method = "min-max"
  test_data1 <- data.frame(
    Value = c(1, 2, 3, 4, 5)
  )
  result1 <- standardize(test_data1, column = "Value", method = "min-max", new_column = FALSE, get_picture = FALSE)
  expect_equal(result1$Value, c(0, 0.25, 0.5, 0.75, 1))
  
  # Test case 2: method = "z-score"
  test_data2 <- data.frame(
    Value = c(1, 2, 3, 4, 5)
  )
  result2 <- standardize(test_data2, column = "Value", method = "z-score", new_column = FALSE, get_picture = FALSE)
  expect_equal(round(as.vector(result2$Value), 2), c(-1.26, -0.63, 0, 0.63, 1.26))
  
  # Test case 3: method = "decimal"
  test_data3 <- data.frame(
    Value = c(100, 200, 300, 400, 500)
  )
  result3 <- standardize(test_data3, column = "Value", method = "decimal", new_column = FALSE, get_picture = FALSE)
  expect_equal(result3$Value, c(0.1, 0.2, 0.3, 0.4, 0.5))
  
  # Test case 4: Invalid method specified
  test_data4 <- data.frame(
    Value = c(1, 2, 3, 4, 5)
  )
  expect_error(standardize(test_data4, column = "Value", method = "invalid_method", new_column = FALSE, get_picture = FALSE), "Invalid method specified.")
})
