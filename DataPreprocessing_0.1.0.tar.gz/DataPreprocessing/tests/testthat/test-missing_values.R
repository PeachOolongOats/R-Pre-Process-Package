test_that("missing_values handles missing values correctly", {
  # Test case 1: Numeric variable, fill_method = previous
  test_data1 <- data.frame(
    Value = c(1, NA, 3, NA, 5)
  )
  result1 <- missing_values(test_data1, column = "Value", fill_method = "previous")
  expect_equal(result1$Value, c(1, 1, 3, 3, 5))
  
  # Test case 2: Non-numeric variable, fill_method = fixed
  test_data2 <- data.frame(
    Category = c("A", NA, "B", "B", "A")
  )
  result2 <- missing_values(test_data2, column = "Category", fill_method = "fixed", fill_value = "A")
  expect_equal(result2$Category, c("A", "A", "B", "B", "A"))
  
  # Test case 3: Non-numeric variable, fill_method = mean (should raise error)
  test_data3 <- data.frame(
    Category = c("A", NA, "B", "B", "A")
  )
  expect_error(missing_values(test_data3, column = "Category", fill_method = "mean"), 
               "For non-numeric variables, fill_method must be 'mode', 'previous', 'next', or 'fixed'.")
})

test_that("missing_values handles NA values at start and end correctly", {
  # Test case 1: First value is NA, fill_method = "previous"
  test_data1 <- data.frame(
    Value = c(NA, 2, 3, 4, 5)
  )
  expect_error(missing_values(test_data1, column = "Value", fill_method = "previous"),
               "The first value is NA. Cannot use 'previous' method.")
  
  # Test case 2: Last value is NA, fill_method = "next"
  test_data2 <- data.frame(
    Value = c(1, 2, 3, 4, NA)
  )
  expect_error(missing_values(test_data2, column = "Value", fill_method = "next"),
               "The last value is NA. Cannot use 'next' method.")
})

