test_that("normal_test function works correctly", {
  # Test case 1:
  data <- data.frame(
    Feature1 = c(1.2, 2.3, 3.1, 4.5),
    Feature2 = c(3.4, 4.5, 2.9, 3.2)
  )
  result1 <- normal_test(data, significance_level = 0.05, verbose = FALSE)
  expected_result1 <- c("Feature1", "Feature2")
  expect_equal(expected_result1, result1)

  # Test case 2:
  data <- "a"
  expect_error(normal_test(data, significance_level = 0.05, verbose = FALSE), "Error: Input data must be a data frame.")

  # Test case 3:
  data <- data.frame(
    Feature1 = c(1.2, 2.3, 3.1, 4.5),
    Class = factor(c("A", "B", "A", "B")),
    Feature2 = c(3.4, 4.5, 2.9, 3.2)
  )
  expect_error(normal_test(data, significance_level = 0.05, verbose = FALSE), "Error: The test can only test numeric variables.")

})
