test_that("balanced_sampling raises an error with single class datasets", {
  # test 1
  data <- data.frame(
    feature1 = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
    feature2 = c(0, 1, 0, 1, 0, 1, 0, 1, 0, 1),
    class = c("A", "A", "A", "A", "A", "A", "A", "A", "A", "A")
  )
  expect_error(
    balanced_sampling(data, class = "class", get_picture = FALSE, print_result = FALSE),
    "The response variable has only one class."
  )

  # test 2
  data <- data.frame(
    feature1 = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
    feature2 = c(0, 1, 0, 1, 0, 1, 0, 1, 0, 1),
    class = c("A", "A", "A", "A", "B", "B", "B", "B", "C", "C")
  )
  result <- balanced_sampling(data, class = "class", get_picture = FALSE, print_result = FALSE)
  new_distribution <- table(result$class)
  expect_equal(sum(new_distribution), 10)
  expect_true(all(new_distribution >= 3))

  # test 3
  data <- data.frame(
    feature1 = as.Date(c('2023-1-3', '2023-3-3', '2024-1-3', '2022-4-3', '2013-5-9', '2007-1-3', '2021-1-23', '2007-1-13', '2018-6-3', '2023-1-3')),
    feature2 = c(0, 1, 0, 1, 0, 1, 0, 1, 0, 1),
    class = c("A", "A", "A", "A", "B", "B", "B", "B", "C", "C")
  )

  expect_error(
    balanced_sampling(data, class = "class", get_picture = FALSE, print_result = FALSE),
    "The current implementation of ROSE handles only continuous and categorical variables."
  )

  # test 4
  data <- data.frame(
    feature1 = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
    feature2 = c(0, 1, 0, 1, 0, 1, 0, 1, 0, 1),
    class = c("A", "A", "A", "A", "A", "A", "A", "A", "A", "A")
  )
  expect_error(
    balanced_sampling(data, class = "miss_class", get_picture = FALSE, print_result = FALSE),
    "The class column does not exist in the dataframe."
  )
})
