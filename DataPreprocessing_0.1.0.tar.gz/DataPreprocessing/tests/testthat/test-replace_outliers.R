test_that("replace_outliers replaces outliers correctly", {
  # Test case 1: method = "IQR", replace_method = "mean"
  test_data1 <- data.frame(
    Value =c(1, 2, 3, 4, 5, 100)  # Include an outlier (100)
  )
  result1 <- replace_outliers(test_data1, column = "Value", method = "IQR", replace_method = "mean", new_column = FALSE, get_picture = FALSE)
  expect_equal(result1$Value, c(1, 2, 3, 4, 5, mean(test_data1$Value[-6])))  # Check if the outlier is replaced with mean
  
  # Test case 2: method = "MAD", replace_method = "zero"
  test_data2 <- data.frame(
    Value = c(1, 2, 3, 4, 5, 100)  # Include an outlier (100)
  )
  result2 <- replace_outliers(test_data2, column = "Value", method = "MAD", replace_method = "zero", new_column = FALSE, get_picture = FALSE)
  expect_equal(result2$Value, c(1, 2, 3, 4, 5, 0))  # Check if the outlier is replaced with zero
  
  # Test case 3: method = "3sigma", replace_method = "custom"
  test_data3 <- data.frame(
    Value = c(1.67, 3.33, 3.27, 2.41, 0.46, 1.07, 1.71, 1.99, 4.40, 2.76, 100)  # Include an outlier (100)
  )
  replace_value <- 10  # Custom replacement value
  result3 <- replace_outliers(test_data3, column = "Value", method = "3sigma", replace_method = "custom", replace_value = replace_value, new_column = FALSE, get_picture = FALSE)
  expect_equal(result3$Value, c(1.67, 3.33, 3.27, 2.41, 0.46, 1.07, 1.71, 1.99, 4.40, 2.76, replace_value))  # Check if the outlier is replaced with custom value
})
