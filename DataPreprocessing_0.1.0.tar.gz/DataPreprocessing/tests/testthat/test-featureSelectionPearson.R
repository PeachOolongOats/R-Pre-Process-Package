test_that("featureSelectionPearson selects features correctly", {
  # Test case 1:
  test_data1 <- data.frame(
    feature1 = c(1, 2, 3, 4, 5),
    feature2 = c(2, 4, 6, 8, 10),
    feature3 = c(5, 4, 3, 2, 1),
    feature4 = c(10, 20, 30, 40, 50),
    target = c(1, 2, 3, 4, 5)
  )
  result1 <- featureSelectionPearson(test_data1, features = c("feature1", "feature2", "feature4"),
                                     target = "target", threshold = 0.5, get_picture = FALSE, print_result = FALSE)
  expect_equal(result1, c("feature1", "feature2", "feature4"))

  # Test case 2:
  test_data1 <- data.frame(
    feature1 = c(1, 2, 3, 4, 5),
    feature2 = c(2, 4, 6, 8, 10),
    feature3 = c(5, 4, 3, 2, 1),
    feature4 = c(10, 20, 30, 40, 50),
    target = c(1, 2, 3, 4, 5)
  )

  expect_error(featureSelectionPearson(test_data1, features = c("feature1", "feature2", "missing_feature"),
                                       target = "target", threshold = 0.5, get_picture = FALSE, print_result = FALSE),
               "One or more features not found in the dataset.")

  # Test case 3:
  test_data1 <- data.frame(
    feature1 = c(1, 2, 3, 4, 5),
    feature2 = c(2, 4, 6, 8, 10),
    feature3 = c(5, 4, 3, 2, 1),
    feature4 = c(10, 20, 30, 40, 50),
    target = c(1, 2, 3, 4, 5)
  )

  expect_error(featureSelectionPearson(test_data1, features = c("feature1", "feature2", "feature3"),
                                       target = "missing_target", threshold = 0.5, get_picture = FALSE, print_result = FALSE),
               "Target variable not found in the dataset.")
})
