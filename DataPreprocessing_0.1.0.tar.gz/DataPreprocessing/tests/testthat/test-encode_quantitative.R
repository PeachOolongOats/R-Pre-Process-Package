test_that("encode_quantitative encodes quantitative variables correctly", {
  # Test case 1: Encoding using mean
  test_data1 <- data.frame(
    Value = c(1, 2, 3, 4, 5)
  )
  result1 <- encode_quantitative(test_data1, column = "Value", method = "mean", new_column = FALSE)
  expect_equal(result1$Value, c(0, 0, 1, 1, 1))
  
  # Test case 2: Encoding using quantile
  test_data2 <- data.frame(
    Value = c(1, 2, 3, 4, 5)
  )
  result2 <- encode_quantitative(test_data2, column = "Value", method = "quantile", q = 2, new_column = FALSE)
  expect_equal(result2$Value, c(1, 1, 1, 2, 2))
  
  # Test case 3: Handling non-numeric variable
  test_data3 <- data.frame(
    Category = c("A", "B", "A", "C", "B")
  )
  expect_error(encode_quantitative(test_data3, column = "Category", method = "mean", new_column = FALSE),
               "Column 'Category' is not numeric.")
  
  # Test case 4: Handling invalid q parameter
  test_data4 <- data.frame(
    Value = c(1, 2, 3, 4, 5)
  )
  expect_error(encode_quantitative(test_data4, column = "Value", method = "quantile", q = 1.5, new_column = FALSE),
               "Invalid q parameter. q must be an integer and at least 2.")
})
