test_that("encode_categorical encodes categories correctly", {
  # Test case 1: Encoding without encoding_map
  test_data1 <- data.frame(
    Category = c("A", "B", "A", "C", "B", "D", "C", "A")
  )
  result1 <- encode_categorical(test_data1, column = "Category", encoding_map = NULL, new_column = TRUE, get_picture = FALSE)
  expect_equal(result1$encoded_Category, c(1, 2, 1, 3, 2, 4, 3, 1))

  # Test case 2: Encoding with encoding_map
  encoding_map <- list(A = 1, B = 2, C = 3, D = 5)
  test_data2 <- data.frame(
    Category = c("A", "B", "A", "C", "B", "D", "C", "A")
  )
  result2 <- encode_categorical(test_data2, column = "Category", encoding_map = encoding_map, new_column = TRUE, get_picture = FALSE)
  expect_equal(result2$encoded_Category, c(1, 2, 1, 3, 2, 5, 3, 1))

  # Test case 3: Handling unknown categories with warning
  test_data3 <- data.frame(
    Category = c("A", "B", "A", "C", "E")
  )
  expect_warning(encode_categorical(test_data3, column = "Category", encoding_map = encoding_map, new_column = TRUE, get_picture = FALSE),
                 "Category E not found in encoding map. Encoding as NA.")
})
