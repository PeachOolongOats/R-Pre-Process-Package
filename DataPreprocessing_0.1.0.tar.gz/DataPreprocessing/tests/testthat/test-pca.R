test_that("pca function works correctly", {
  # Test case 1:
  data <- data.frame(
    Feature1 = c(1.2, 2.3, 3.1, 4.5),
    Feature2 = c(3.4, 4.5, 2.9, 3.2)
  )
  result1 <- pca(data, scale_data = TRUE, threshold = 0.95, verbose = FALSE)
  result1$PC1 <- round(result1$PC1, 3)
  expected_result1 <- data.frame(
    PC1 = c(-1.134, -0.342, 0.234, 1.242)
  )
  expect_equal(expected_result1, result1)

  # Test case 2:
  data <- data.frame(
    Feature1 = c(1.2, 2.3, 3.1, NA),
    Feature2 = c(3.4, 4.5, 2.9, 3.2)
  )
  expect_error(pca(data, scale_data = TRUE, threshold = 0.95, verbose = FALSE), "Error: You need to deal with NA first.")

  # Test case 3:
  data <- "data.frame"
  expect_error(pca(data, scale_data = TRUE, threshold = 0.95, verbose = FALSE), "Error: Input data must be a data frame.")

  # Test case 4:
  data <- data.frame(
    Feature1 = c(1.2, 2.3, 3.1, 4.5)
  )
  expect_error(pca(data, scale_data = TRUE, threshold = 0.95, verbose = FALSE), "Error: Input data must contain at least two columns.")

  # Test case 5:
  data <- data.frame(
    Feature1 = c(1.2, 2.3, 3.1, 4.5),
    Feature2 = c(3.4, 4.5, 2.9, 3.2),
    Class = factor(c("A", "B", "A", "B"))
  )
  expect_error(pca(data, scale_data = TRUE, threshold = 0.95, verbose = FALSE), "Error: Not all columns are numeric.")
})
