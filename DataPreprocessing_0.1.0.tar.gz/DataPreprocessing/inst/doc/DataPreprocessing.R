## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(DataPreprocessing)

## -----------------------------------------------------------------------------
# Call encode_categorical function with your data, column name, and optionally encoding map and new_column parameter
data <- data.frame(
  category1 = c("A", "B", "C", "A", "B", "C", "A", "B", "C", "A"),
  category2 = c("a", "b", "a", "b", "a", "b", "a", "b", "a", "b")
)

# Example 1: Default labeling approach
encode_categorical(data, "category1")

## -----------------------------------------------------------------------------
# Example 2: Custom labeling approach with a provided encoding map and overwriting the original column
custom_encoding <- list("a" = 2, "b" = 4)
encode_categorical(data, "category2", encoding_map = custom_encoding, new_column = FALSE, get_picture = TRUE)

## -----------------------------------------------------------------------------
# Call encode_quantitative function with your data, column name, method, and optionally q and new_column parameters
data <- data.frame(
  value1 = c(1, 2, 5, 7, 6, 10, 8, 9, 4, 3),
  value2 = c(10, 20, 15, 25, 30, 35, 40, 45, 50, 55)
)

# Example 1: Mean-based encoding and overwriting the original column
encode_quantitative(data, "value1", method = "mean", new_column = FALSE)

# Example 2: Quantile-based encoding with custom number of quantiles and storing in a new column
encode_quantitative(data, "value2", method = "quantile", q = 5, new_column = TRUE)

## -----------------------------------------------------------------------------
# Call standardize function with your data, method, and optionally column and new_column parameters
data <- data.frame(
  value1 = c(100, 200, 300, 400, 500, 600, 700, 800),
  value2 = c(11.56, 10.15, 6.02, 11.24, 9.89, 9.69, 7.06, 9.04)
)

# Example 1: Standardize the first column using min-max scaling and store in new columns
standardize(data, method = "min-max", column = 1, new_column = TRUE)

# Example 2: Standardize the second column using z-score scaling and overwrite original columns
standardize(data, method = "z-score", column = "value2", new_column = FALSE)


## -----------------------------------------------------------------------------
# Call missing_values function with your data, column name, fill_method, and optionally fill_value parameter
data <- data.frame(
  numeric_column = c(1, 2, NA, 4, 5, 8),
  character_column = c("a", "b", NA, "c", NA, "b")
)

# Example 1: Replace missing values in a numeric column with the mean
data_filled <- missing_values(data, "numeric_column", fill_method = "mean")
print(data_filled)

# Example 2: Replace missing values in a character column with the mode
data_filled <- missing_values(data_filled, "character_column", fill_method = "mode")
print(data_filled)

## -----------------------------------------------------------------------------
# Call replace_outliers function with your data, method, replace_method, and replace_value

# Example 1: Default 3 sigma method and replaced by mean
set.seed(1)
data <- data.frame(
  value1 = c(rnorm(19, 5, 1), 10)
)
replace_outliers(data, "value1")

## -----------------------------------------------------------------------------
# Example 2: IQR method and replaced by a specified value 35
data <- data.frame(
  value2 = c(10, 20, 30, 100, 25, 35, 200, 45, 50, 55)
)
replace_outliers(data, "value2", method = "IQR", replace_method = "custom", replace_value = 35)

## -----------------------------------------------------------------------------
# Call balanced_sampling function with your data and class column name
set.seed(1)
data <- data.frame(
  class = c(rep("A", 10), rep("B", 5), rep("C", 3), rep("D", 2)),
  feature1 = rnorm(20),
  feature2 = runif(20)
)
balanced_data <- balanced_sampling(data, 'class')

## -----------------------------------------------------------------------------
# Call featureSelectionPearson function with your dataset, features, target variable, and threshold
data <- data.frame(
  feature1 = c(1, 3, 3, 4, 6),
  feature2 = c(-2, -1, -4, -5, -4),
  feature3 = c(2, 1, 1, 5, 3),
  target = c(10, 20, 30, 40, 50)
)

selected_features <- featureSelectionPearson(data, c("feature1", "feature2", "feature3"), 'target', threshold = 0.6, get_picture = TRUE)
selected_features

## -----------------------------------------------------------------------------
# Call pca function with your dataset
data <- data.frame(
  Feature1 = c(1.2, 2.3, 3.1, 4.5, 2.8, 3.9, 1.8, 4.0, 2.5, 3.6),
  Feature2 = c(3.4, 4.5, 2.9, 3.2, 3.7, 2.6, 3.0, 3.5, 3.1, 2.8),
  Feature3 = c(2.5, 1.8, 3.0, 2.6, 2.4, 3.2, 2.9, 2.1, 2.8, 2.7),
  Feature4 = c(1.8, 2.1, 1.5, 2.0, 1.9, 2.3, 2.2, 1.7, 1.6, 2.4),
  Feature5 = c(4.3, 3.6, 4.2, 3.9, 4.1, 3.8, 4.0, 3.4, 4.4, 3.5)
)
pca(data, scale_data = TRUE, threshold = 0.95, verbose = TRUE)

## -----------------------------------------------------------------------------
# Call normal_test function with your dataset
data <- data.frame(
  Feature1 = c(1.2, 2.3, 3.1, 4.5, 2.8, 3.9, 1.8, 4.0, 2.5, 3.6),
  Feature2 = c(3.4, 4.5, 2.9, 3.2, 3.7, 2.6, 3.0, 3.5, 3.1, 2.8),
  Feature3 = c(2.5, 1.8, 3.0, 2.6, 2.4, 3.2, 2.9, 2.1, 2.8, 2.7),
  Feature4 = c(1.8, 2.1, 1.5, 2.0, 1.9, 2.3, 2.2, 1.7, 1.6, 2.4),
  Feature5 = c(4.3, 3.6, 4.2, 3.9, 4.1, 3.8, 4.0, 3.4, 4.4, 3.5)
)
normal_test(data, significance_level = 0.05, verbose = TRUE)

## -----------------------------------------------------------------------------
# Firstly, we need to fill the missing values in the 'amount' column.
transactions_dataset <- missing_values(transactions_dataset, 'amount', fill_method = "mode")
summary(transactions_dataset$amount)

# Secondly, we need to encode the values in the 'ESG_ranking', 'sector', 'company' and 'investment' columns.
transactions_dataset <- encode_quantitative(transactions_dataset, column = "ESG_ranking", method = "quantile", q = 3, new_column = FALSE)
transactions_dataset <- encode_categorical(transactions_dataset, column = 'company', new_column = FALSE)
transactions_dataset <- encode_categorical(transactions_dataset, column = 'sector', new_column = FALSE, encoding_map = c("AUTO"=1, "BANK"=2, "FMCG"=3, "RETAIL"=4, "TECH"=5))
transactions_dataset <- encode_categorical(transactions_dataset, column = 'investment', new_column = FALSE)

# Thirdly, we need to adjust the outliers in the 'expected_return' column.
summary(transactions_dataset$expected_return)
transactions_dataset <- replace_outliers(transactions_dataset, column = "expected_return", method = "IQR", replace_method = "median", new_column = FALSE)
summary(transactions_dataset$expected_return)

# Fourthly, we need to standardize the 'nominal_return' values.
transactions_dataset <- standardize(transactions_dataset, method = "min-max", column = "nominal_return", new_column = FALSE)

# Fifthly, we want to use feature selection method to select the most relevant features to stock price.
features <- c("Sharpe_Ratio", "company", "PE_ratio", "EPS_ratio", "PS_ratio", "PB_ratio", "NetProfitMargin_ratio", "current_ratio" , "roa_ratio", "roe_ratio")
selected_features <- featureSelectionPearson(transactions_dataset, features, 'price_BUY', threshold = 0.3, get_picture = TRUE)

# Sixthly, we use PCA dimentional reduction method to reduce the dimention of the selected features.
PCA_features <- pca(transactions_dataset[, c(selected_features,"price_BUY")])
head(PCA_features)
transactions_dataset <- cbind(transactions_dataset, PCA_features)

# Seventhly, we want to balance the investment classes.
test_data <- transactions_dataset
transactions_dataset <- balanced_sampling(test_data[, c('price_BUY',"PC1","PC2","company")], class = "company")

# Finally, we want to test which variable follows normal distribution.
normal_columns <- normal_test(transactions_dataset[1:5000, c('price_BUY',"PC1","PC2")])
normal_columns

